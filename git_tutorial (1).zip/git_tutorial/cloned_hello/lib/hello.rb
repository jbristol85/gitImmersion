# Default is World
# Author: Josh Bristol
name = ARGV.first || "World"

puts "Hello, #{name}!"